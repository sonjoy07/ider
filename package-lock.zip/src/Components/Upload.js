import React, { Fragment, useState ,useReducer} from 'react'
import { Button, Row, Col, Form, FormGroup, Label, Input, FormText } from 'reactstrap';
import { CsvToHtmlTable } from 'react-csv-to-table';
import {useDispatch,useSelector} from 'react-redux'
import {SetCsv} from './../actions/csv'

function Upload() {
    const [fileCsv, setFileCsv] = useState()
    const [csvValue, setCsvValue] = useState('')
    const state = useSelector(state => state.csv)
    const dispatch = useDispatch()
    console.log('dispatch',state)
    // const [cart, setCart] = useReducer(cartReducer, []);
    const onFileChange = e => {
        console.log('upload', e.target.files[0])
        setFileCsv(e.target.file)
    };
    const upload = (e) => {
        debugger
        const csv = fileCsv
        const reader = new FileReader();
        reader.onload = (e) => {
            const text = e.targer.result
            console.log(text)
        }
        reader.readAsText(csv)
        // setCsvValue(fileCsv)
    }

    const download = () => {
        const rows = [
            ["name1", "city1", "some other info"],
            ["name2", "city2", "more info"]
        ];

        let csvContent = "data:text/csv;charset=utf-8,";

        rows.forEach(function (rowArray) {
            let row = rowArray.join(",");
            csvContent += row + "\r\n";           
        });
        var encodedUri = encodeURI(csvContent);
        var link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "my_data.csv");
        document.body.appendChild(link); // Required for FF
        dispatch(SetCsv(rows))
        // link.click();
    }
    console.log('csvValue', Object.keys(csvValue).length === 0)
    return (
        <Fragment>
            <Form inline>
                <Row form>
                    <Col md={6}>
                        <FormGroup>
                            <Label for="exampleEmail">Upload</Label>
                            <Input type="file" onChange={onFileChange} name="email" id="exampleEmail" placeholder="with a placeholder" />
                        </FormGroup>
                    </Col>

                </Row>

                <Button color="info" onClick={upload}>Submit</Button>
            </Form>

            <button onClick={download}>click</button>

            {
                Object.keys(csvValue).length !== 0 && <CsvToHtmlTable
                    data={fileCsv}
                    csvDelimiter=","
                />
            }
        </Fragment>

    )
}

export default Upload
