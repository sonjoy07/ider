export const SetCsv = data => ({
    type: 'ADD_CSV',
    data
})