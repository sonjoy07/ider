const csvReducersDefaultState = []

export default (state = csvReducersDefaultState, action) => {
    switch (action.type) {
        case 'ADD_CSV':
            debugger;
            return action.data
        default:
            return state
    }
}